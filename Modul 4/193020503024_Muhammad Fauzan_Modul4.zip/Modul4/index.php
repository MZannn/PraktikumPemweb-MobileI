<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-xl navbar-dark" style="background-color:#006bb3">
  <a class="navbar-brand mb-0 h1" href="index.php">Pemrograman Web & Mobile</a>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="chart.php">Chart</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="index.php">Pemilu</a>
      </li>    
  </div>
</nav>
<br>
<h1 style="margin-left:20px;"> PEMILIHAN UMUM</h1>
<br>
<form method="post">
<table width="75%" cellpadding="5px" style="margin-left:20px;">
<tr colspan="4">
        <td width="20%">NIK</td>
        <td width="2%"> : </td>
        <td><input class="lebar" type="number" name="NIK"/></td>
    </tr>
    <tr colspan="4">
        <td width="20%">Calon Ketua</td>
        <td width="2%"> : </td>
        <td><select name="pilihan" class="lebar">
            <option value="Raihan">1. Raihan</option>
            <option value="Irawan">2. Irawan</option>
            <option value="Lukman">3. Lukman</option>
            <option value="Abigael">4. Abigael</option>
            <option value="Gerry">5. Gerry</option>
        </select>
        </td>
    </tr>
    <tr><td><td></td></td><td><button class="btn btn-primary mb-10" name="kirim" type="submit" >Kirim</button></td></tr>
</table>


<form>
<?php 
require './koneksi.php';
if (isset($_POST["kirim"])) {
// menangkap data yang di kirim dari form
$pilihan = $_POST['pilihan'];
$NIK = $_POST['NIK'];

$data1 = mysqli_query($koneksi,"select * from suara where NIK='$NIK'");

// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data1);

if($cek <= 0){

$data =mysqli_query($koneksi,"INSERT INTO `suara` (`id_suara`, `NIK`, `pilihan`, `waktu`) VALUES ('', '$NIK', '$pilihan', CURRENT_TIME())");

if ($data) {
    ?>
<script language="javascript">
alert("Data Berhasil Ditambah");
</script>
<?php

}}else if ($cek >= 0){
    ?>
    <script language="javascript">
    alert("Maaf Id sudah digunakan ");
    
    </script>
    <?php  

}
}
?> 	
</body>
</html>